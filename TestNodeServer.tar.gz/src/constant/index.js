"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NewError = exports.constant = void 0;
var constant;
(function (constant) {
    constant["SIMP_SERVER_PORT"] = "SIMP_SERVER_PORT";
    constant["SIMP_SERVER_CONF"] = "SIMP_SERVER_CONF";
    constant["SIMP_SERVER_STORAGE"] = "SIMP_SERVER_STORAGE";
})(constant || (exports.constant = constant = {}));
var NewError = function (code, msg) {
    return {
        code: code || -1,
        msg: msg
    };
};
exports.NewError = NewError;
//# sourceMappingURL=index.js.map