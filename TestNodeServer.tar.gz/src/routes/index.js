"use strict";
// src/routes/index.ts
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = require("express");
function routes() {
    var r = (0, express_1.Router)();
    // 根目录
    r.get("/", function (req, res) {
        return res.status(200).send("Hello Shinp!!!");
    });
    return r;
}
exports.default = routes;
//# sourceMappingURL=index.js.map