"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var lib_1 = require("./src/lib");
var routes_1 = __importDefault(require("./src/routes"));
var ctx = (0, lib_1.NewHttpServerCtx)("simp.yaml");
ctx.use(routes_1.default);
(0, lib_1.NewSimpHttpServer)(ctx);
process.on("uncaughtException", function (err) {
    console.error(err);
});
process.on("unhandledRejection", function (reason, p) {
    console.error(reason, p);
});
//# sourceMappingURL=app.js.map